# WebDev Agency - Premium Web Development Portfolio

Un website ultra-modern, complet funcțional, pentru agenția ta de Web Development. Design 2026 cu dark mode, glassmorphism și animații fluide.

## ✨ Caracteristici Principale

### Design & UX
- **Design Ultra-Modern 2026** - Dark theme cu glassmorphism și gradient neon elegant
- **Animații Fluide** - Animații smooth la scroll folosind Intersection Observer API
- **Efecte Parallax** - Tranziții și transformări impresionante prin scroll
- **Particule Animate** - Canvas animat cu particule în Hero section
- **Hover Effects 3D** - Carduri cu efecte 3D la hover
- **Responsive Design** - Perfect optimizat pentru toate dispozitivele (mobile-first)

### Secțiuni Implementate

1. **Hero Section**
   - Full-screen cu titlu animat masiv
   - Particule animate pe canvas
   - Butoane CTA cu micro-animații
   - Statistici animate

2. **Despre Mine**
   - Prezentare profesională
   - Avatar rotund cu efecte glassmorphism
   - Carduri cu iconițe SVG animate
   - Fade-up animations

3. **Servicii Premium**
   - 4 carduri (Web Design, Development, SEO, Automatizări)
   - Efecte 3D la hover
   - Gradient borders animate
   - Smooth transitions

4. **Proiecte Realizate**
   - Scroll orizontal (horizontal panel slider)
   - Imagini demo de pe Pexels
   - Overlay gradients animate
   - CTA buttons pentru fiecare proiect

5. **Procesul de Lucru**
   - 4 pași animați (Consultanță → Design → Development → Lansare)
   - Animație step-by-step automată
   - Progress indicators
   - Carduri interactive

6. **Skills & Expertiza**
   - Progress bars animate cu numărătoare
   - Iconițe SVG pentru fiecare skill
   - Efecte de animație la scroll
   - Gradient colors pentru fiecare skill

7. **Testimoniale**
   - Slider automat (schimbare la 5 secunde)
   - Avatar, nume, rol, rating cu stele
   - Navigation dots interactive
   - Smooth transitions

8. **CTA Puternic**
   - Design impactant cu gradient background
   - Modal pop-up pentru "Cere Ofertă"
   - Animații de intrare/ieșire
   - Call-to-action clar

9. **Contact Funcțional**
   - Formular complet cu validare
   - Integrare Supabase (salvare mesaje în baza de date)
   - Feedback vizual la trimitere
   - Informații de contact + social media links

10. **Footer Premium**
    - Link-uri rapide către secțiuni
    - Informații de contact
    - Design minimal și elegant

### Funcționalități Tehnice

- **Navigație Sticky** - Navbar cu blur effect la scroll
- **Smooth Scrolling** - Scroll fluid între secțiuni
- **Database Integration** - Formular conectat la Supabase
- **Animații Custom** - Keyframe animations pentru toate elementele
- **SEO Optimizat** - Meta tags complete, Open Graph, descrieri
- **Performance** - Cod optimizat, imagini de pe Pexels (external links)
- **TypeScript** - Type-safe code pentru mentenabilitate
- **Component Architecture** - Componente modulare și reutilizabile

## 🚀 Tehnologii Folosite

- **React 18** - UI framework modern
- **TypeScript** - Type safety
- **Vite** - Build tool ultra-rapid
- **Tailwind CSS** - Utility-first CSS framework
- **Supabase** - Backend as a Service (database + auth ready)
- **Lucide React** - Iconițe SVG moderne
- **Canvas API** - Animații particule

## 📦 Instalare și Configurare

### 1. Instalează Dependințele

```bash
npm install
```

### 2. Configurare Supabase

Fișierul `.env` este deja configurat cu credențialele Supabase. Baza de date are tabela `contact_messages` creată automat.

### 3. Pornește Serverul de Dezvoltare

Serverul pornește automat! Nu trebuie să rulezi manual `npm run dev`.

### 4. Build pentru Producție

```bash
npm run build
```

## 📁 Structura Proiectului

```
src/
├── components/
│   ├── Navbar.tsx          # Navigație sticky cu blur
│   ├── Hero.tsx            # Hero section cu particule
│   ├── About.tsx           # Despre mine
│   ├── Services.tsx        # Servicii cu carduri 3D
│   ├── Projects.tsx        # Slider orizontal proiecte
│   ├── Process.tsx         # Proces de lucru animat
│   ├── Skills.tsx          # Skills cu progress bars
│   ├── Testimonials.tsx    # Slider testimoniale
│   ├── CTA.tsx             # Call-to-action + Modal
│   ├── Contact.tsx         # Formular funcțional
│   └── Footer.tsx          # Footer premium
├── lib/
│   └── supabase.ts         # Client Supabase
├── App.tsx                 # Componenta principală
├── index.css               # Stiluri custom + animații
└── main.tsx                # Entry point
```

## 🎨 Personalizare

### Culori și Gradiente

Toate gradientele folosesc cyan → blue → purple. Pentru a schimba schema de culori, caută în fișierele componentelor:

```tsx
// Exemplu gradient
from-cyan-400 to-purple-600
from-cyan-500 via-blue-500 to-purple-600
```

### Conținut

Pentru a modifica textele și conținutul:

1. **Hero** - `src/components/Hero.tsx` - liniile 45-55
2. **Despre** - `src/components/About.tsx` - liniile 60-70
3. **Servicii** - `src/components/Services.tsx` - array-ul `services`
4. **Proiecte** - `src/components/Projects.tsx` - array-ul `projects`
5. **Testimoniale** - `src/components/Testimonials.tsx` - array-ul `testimonials`

### Informații Contact

Modifică în `src/components/Contact.tsx` și `src/components/Footer.tsx`:

```tsx
{ icon: Mail, label: 'Email', value: 'TU_EMAIL@exemplu.ro' }
{ icon: Phone, label: 'Telefon', value: '+40 TU_NUMAR' }
```

### Social Media

Link-urile social media sunt în `src/components/Contact.tsx` (linia ~145):

```tsx
{ icon: Linkedin, href: 'https://linkedin.com/in/TU' }
{ icon: Github, href: 'https://github.com/TU' }
```

## 🔧 Funcționalități Database

Formularul de contact salvează automat mesajele în Supabase:

- Tabela: `contact_messages`
- Coloane: `name`, `email`, `phone`, `message`, `status`, `created_at`
- RLS: Activat (public insert, authenticated read)

## 🎯 Features Highlight

✅ Design 2026 ultra-modern cu dark & glassmorphism
✅ Animații fluide la scroll (fade-in, slide-up, parallax)
✅ Hero full-screen cu particule animate pe canvas
✅ Navigație sticky cu blur effect
✅ Carduri 3D animate la hover
✅ Slider orizontal pentru proiecte (scroll-triggered)
✅ Progress bars animate pentru skills
✅ Proces de lucru în 4 pași cu animații step-by-step
✅ Testimoniale cu slider automat
✅ CTA puternic cu modal pop-up
✅ Formular funcțional conectat la Supabase
✅ Fully responsive (mobile-first)
✅ SEO optimizat
✅ Performance optimizat

## 📱 Responsive Breakpoints

- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

Toate componentele sunt optimizate pentru toate dimensiunile de ecran.

## 🚀 Deployment

Proiectul poate fi deploiat pe:

- **Vercel** (recomandat)
- **Netlify**
- **GitHub Pages**
- Orice platformă care suportă aplicații React

```bash
npm run build
# Folder-ul dist/ conține fișierele pentru producție
```

## 📝 Licență

Acest proiect este creat pentru uz personal/comercial.

---

**Creat cu** ❤️ **și** 💻 **pentru WebDev Agency**
