import { useLanguage } from '../contexts/LanguageContext';
import { Globe } from 'lucide-react';

const LanguageSelector = ({ showFullScreen = true }: { showFullScreen?: boolean }) => {
  const { language, setLanguage } = useLanguage();

  if (!showFullScreen) {
    return (
      <div className="flex gap-2">
        <button
          onClick={() => setLanguage('ro')}
          className={`px-3 py-1 rounded-lg font-semibold transition-all duration-300 text-sm ${
            language === 'ro'
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white'
              : 'bg-white/5 text-gray-300 hover:bg-white/10'
          }`}
        >
          RO
        </button>
        <button
          onClick={() => setLanguage('en')}
          className={`px-3 py-1 rounded-lg font-semibold transition-all duration-300 text-sm ${
            language === 'en'
              ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white'
              : 'bg-white/5 text-gray-300 hover:bg-white/10'
          }`}
        >
          EN
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/90 backdrop-blur-sm animate-fade-in">
      <div className="text-center animate-slide-up">
        <div className="mb-8">
          <Globe size={64} className="mx-auto text-cyan-400 mb-6" />
          <h1 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              Choose Language
            </span>
          </h1>
          <p className="text-xl text-gray-400 mb-2">Selectează Limba</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 justify-center">
          <button
            onClick={() => setLanguage('ro')}
            className="group relative flex flex-col items-center gap-4 p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl hover:bg-white/10 transition-all duration-300 hover:scale-105"
          >
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-600 rounded-3xl opacity-0 group-hover:opacity-100 transition duration-300 blur-xl"></div>

            <div className="relative text-8xl">🇷🇴</div>
            <h2 className="text-3xl font-bold text-white">Română</h2>
            <p className="text-gray-400">Romanian</p>

            <div className="mt-4 px-6 py-2 bg-blue-500/20 rounded-full border border-blue-500/50">
              <span className="text-blue-400 font-semibold">Select</span>
            </div>
          </button>

          <button
            onClick={() => setLanguage('en')}
            className="group relative flex flex-col items-center gap-4 p-8 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl hover:bg-white/10 transition-all duration-300 hover:scale-105"
          >
            <div className="absolute -inset-0.5 bg-gradient-to-r from-red-500 to-yellow-500 rounded-3xl opacity-0 group-hover:opacity-100 transition duration-300 blur-xl"></div>

            <div className="relative text-8xl">🇬🇧</div>
            <h2 className="text-3xl font-bold text-white">English</h2>
            <p className="text-gray-400">Engleza</p>

            <div className="mt-4 px-6 py-2 bg-red-500/20 rounded-full border border-red-500/50">
              <span className="text-red-400 font-semibold">Select</span>
            </div>
          </button>
        </div>

        <p className="text-gray-500 text-sm mt-12">
          {language === 'ro' ? 'Poți schimba limba oricând din navbar' : 'You can change the language anytime from navbar'}
        </p>
      </div>
    </div>
  );
};

export default LanguageSelector;
