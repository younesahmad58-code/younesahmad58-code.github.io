import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';

const projects = [
  {
    title: 'E-Commerce Platform',
    category: 'Full-Stack Development',
    description: 'Platformă completă de comerț electronic cu sistem de plăți, dashboard admin și notificări în timp real.',
    image: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-cyan-500 to-blue-600',
  },
  {
    title: 'SaaS Dashboard',
    category: 'Web Application',
    description: 'Dashboard analytic complex cu grafice interactive, export de date și integrări multiple.',
    image: 'https://images.pexels.com/photos/270408/pexels-photo-270408.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-blue-500 to-purple-600',
  },
  {
    title: 'Corporate Website',
    category: 'Design & Development',
    description: 'Website corporate premium cu animații avansate, CMS personalizat și optimizare SEO completă.',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-purple-500 to-pink-600',
  },
  {
    title: 'Mobile App Landing',
    category: 'Landing Page',
    description: 'Landing page optimizată pentru conversie, cu formulare inteligente și A/B testing integrat.',
    image: 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800',
    gradient: 'from-pink-500 to-red-600',
  },
];

const Projects = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 650;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section
      id="proiecte"
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6 mb-16">
        <div
          className={`text-center transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              {t.projects.title}
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.projects.subtitle}
          </p>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-8 overflow-x-auto pb-8 px-6 scrollbar-hide snap-x snap-mandatory"
        style={{ scrollbarWidth: 'none' }}
      >
        {projects.map((project, index) => (
          <div
            key={index}
            className={`flex-shrink-0 w-[90vw] md:w-[600px] snap-center transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}
            style={{ transitionDelay: `${index * 150}ms` }}
          >
            <div className="group relative h-full">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-3xl opacity-0 group-hover:opacity-100 transition duration-500 blur-xl"></div>

              <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-3xl overflow-hidden h-full">
                <div className="relative h-80 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${project.gradient} opacity-40 group-hover:opacity-60 transition-opacity duration-300`}></div>

                  <div className="absolute top-4 right-4 bg-white/10 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
                    <span className="text-sm text-white font-medium">{project.category}</span>
                  </div>
                </div>

                <div className="p-8">
                  <h3 className="text-3xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-cyan-400 group-hover:to-purple-600 group-hover:bg-clip-text transition-all">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-center gap-4 mt-8">
        <button
          onClick={() => scroll('left')}
          className="p-3 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full text-white hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-110 group"
        >
          <ChevronLeft className="group-hover:-translate-x-1 transition-transform" size={24} />
        </button>
        <p className="text-gray-500 text-sm">{t.projects.slide}</p>
        <button
          onClick={() => scroll('right')}
          className="p-3 bg-gradient-to-br from-purple-600 to-pink-600 rounded-full text-white hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:scale-110 group"
        >
          <ChevronRight className="group-hover:translate-x-1 transition-transform" size={24} />
        </button>
      </div>
    </section>
  );
};

export default Projects;
