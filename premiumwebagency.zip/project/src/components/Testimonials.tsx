import { useEffect, useRef, useState } from 'react';
import { Star, Quote } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';

const testimonials = [
  {
    name: 'Andrei Popescu',
    role: 'CEO, TechStart',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: 'Colaborarea a fost excepțională! Website-ul nostru nou a crescut conversiile cu 150% în primele 3 luni. Profesionalism și atenție la detalii de top.',
    rating: 5,
  },
  {
    name: 'Maria Ionescu',
    role: 'Founder, StyleBoutique',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: 'Am primit exact ce mi-am dorit și mai mult! Designul este modern, site-ul rapid și optimizat perfect pentru mobil. Recomand cu încredere!',
    rating: 5,
  },
  {
    name: 'Cristian Dumitrescu',
    role: 'Product Manager, InnovateSoft',
    avatar: 'https://images.pexels.com/photos/3778680/pexels-photo-3778680.jpeg?auto=compress&cs=tinysrgb&w=200',
    text: 'Experiență de nivel enterprise. A înțeles perfect nevoile noastre tehnice complexe și a livrat o soluție scalabilă și performantă.',
    rating: 5,
  },
];

const Testimonials = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const [isVisible, setIsVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section
      id="testimoniale"
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden"
    >
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              {t.testimonials.title}
            </span>
          </h2>
          <p className="text-xl text-gray-400">
            {t.testimonials.subtitle}
          </p>
        </div>

        <div className="relative">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`transition-all duration-700 ${
                index === currentIndex
                  ? 'opacity-100 scale-100 relative'
                  : 'opacity-0 scale-95 absolute inset-0 pointer-events-none'
              }`}
            >
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-3xl opacity-20 blur-xl"></div>

                <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12">
                  <Quote size={48} className="text-cyan-400/30 mb-6" />

                  <p className="text-xl md:text-2xl text-gray-300 leading-relaxed mb-8 italic">
                    "{testimonial.text}"
                  </p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <img
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-16 h-16 rounded-full object-cover border-2 border-cyan-400/50"
                      />
                      <div>
                        <div className="text-white font-bold text-lg">{testimonial.name}</div>
                        <div className="text-gray-400">{testimonial.role}</div>
                      </div>
                    </div>

                    <div className="flex gap-1">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star key={i} size={20} className="text-yellow-400 fill-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center gap-2 mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                currentIndex === index
                  ? 'w-12 bg-gradient-to-r from-cyan-400 to-purple-600'
                  : 'w-2 bg-gray-700'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
