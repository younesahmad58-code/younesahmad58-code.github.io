import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';
import LanguageSelector from './LanguageSelector';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-gray-900/80 backdrop-blur-xl shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent animate-gradient">
            WebDev Agency
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => scrollToSection('home')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.home}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('despre')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.about}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('servicii')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.services}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('proiecte')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.projects}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('proces')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.process}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('testimoniale')}
              className="text-gray-300 hover:text-white transition-colors duration-300 relative group"
            >
              {t.nav.testimonials}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-600 group-hover:w-full transition-all duration-300"></span>
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-full text-white font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:scale-105"
            >
              {t.nav.cta}
            </button>
            <LanguageSelector showFullScreen={false} />
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 space-y-4 bg-gray-900/95 backdrop-blur-xl rounded-2xl p-6 animate-slide-down">
            <button onClick={() => scrollToSection('home')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.home}</button>
            <button onClick={() => scrollToSection('despre')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.about}</button>
            <button onClick={() => scrollToSection('servicii')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.services}</button>
            <button onClick={() => scrollToSection('proiecte')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.projects}</button>
            <button onClick={() => scrollToSection('proces')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.process}</button>
            <button onClick={() => scrollToSection('testimoniale')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.testimonials}</button>
            <button onClick={() => scrollToSection('contact')} className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2">{t.nav.contact}</button>
            <div className="border-t border-white/10 pt-4 mt-4">
              <LanguageSelector showFullScreen={false} />
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
