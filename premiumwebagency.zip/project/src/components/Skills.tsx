import { useEffect, useRef, useState } from 'react';
import { Laptop, Smartphone, Database, Cloud, Shield, Layers } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';

const Skills = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const skills = t.skills.items.map((skill: any, index: number) => {
    const iconMap = [Laptop, Database, Smartphone, Cloud, Shield, Layers];
    return {
      name: skill.name,
      level: skill.level,
      icon: iconMap[index],
      color: ['from-cyan-400 to-blue-500', 'from-blue-500 to-purple-500', 'from-purple-500 to-pink-500', 'from-pink-500 to-red-500', 'from-red-500 to-orange-500', 'from-orange-500 to-yellow-500'][index],
    };
  });

  const [isVisible, setIsVisible] = useState(false);
  const [animatedLevels, setAnimatedLevels] = useState<number[]>(skills.map(() => 0));
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const timers = skills.map((skill, index) => {
      return setTimeout(() => {
        let currentLevel = 0;
        const interval = setInterval(() => {
          if (currentLevel >= skill.level) {
            clearInterval(interval);
          } else {
            currentLevel += 2;
            setAnimatedLevels((prev) => {
              const newLevels = [...prev];
              newLevels[index] = Math.min(currentLevel, skill.level);
              return newLevels;
            });
          }
        }, 20);
      }, index * 150);
    });

    return () => timers.forEach((timer) => clearTimeout(timer));
  }, [isVisible]);

  return (
    <section
      id="skills"
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              {t.skills.title}
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.skills.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {skills.map((skill, index) => (
            <div
              key={index}
              className={`transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all duration-300 group">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${skill.color} rounded-xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-12 transition-all duration-300`}>
                      <skill.icon size={24} className="text-white" />
                    </div>
                    <span className="text-lg font-semibold text-white">{skill.name}</span>
                  </div>
                  <span className={`text-2xl font-bold bg-gradient-to-r ${skill.color} bg-clip-text text-transparent`}>
                    {animatedLevels[index]}%
                  </span>
                </div>

                <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
                  <div
                    className={`absolute inset-y-0 left-0 bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                    style={{ width: `${animatedLevels[index]}%` }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
