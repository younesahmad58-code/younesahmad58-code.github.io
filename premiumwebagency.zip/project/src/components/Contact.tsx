import { useState, useEffect, useRef, FormEvent } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle, Linkedin, Github, Instagram, MessageCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';

const Contact = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const [isVisible, setIsVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const { error } = await supabase.from('contact_messages').insert([
        {
          name: formData.name,
          email: formData.email,
          phone: formData.phone || null,
          message: formData.message,
        },
      ]);

      if (error) throw error;

      setShowSuccess(true);
      setFormData({ name: '', email: '', phone: '', message: '' });

      setTimeout(() => {
        setShowSuccess(false);
      }, 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
      alert(language === 'ro' ? 'A apărut o eroare. Te rog încearcă din nou.' : 'An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              {t.contact.title}
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.contact.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div
            className={`space-y-8 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
            }`}
          >
            <div>
              <h3 className="text-3xl font-bold text-white mb-6">
                {t.contact.heading}
              </h3>
              <p className="text-gray-400 leading-relaxed mb-8">
                {t.contact.description}
              </p>
            </div>

            <div className="space-y-6">
              {[
                { icon: Mail, label: language === 'ro' ? 'Email' : 'Email', value: 'younesahmad58@yahoo.com' },
                { icon: Phone, label: language === 'ro' ? 'Telefon' : 'Phone', value: '+40 760 895 235' },
                { icon: MapPin, label: language === 'ro' ? 'Locație' : 'Location', value: 'România' },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center gap-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all duration-300 group"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-purple-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <item.icon size={24} className="text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">{item.label}</div>
                    <div className="text-white font-semibold">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div>
              <p className="text-gray-400 mb-4">{t.contact.contactDirect}</p>
              <div className="flex gap-4 flex-wrap">
                <a
                  href="https://wa.me/40760895235"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial px-4 py-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-green-500/50 transition-all duration-300 hover:scale-110 group"
                  title="WhatsApp"
                >
                  <MessageCircle size={20} className="text-white" />
                  <span className="hidden sm:inline text-white font-semibold text-sm">WhatsApp</span>
                </a>
                <a
                  href="https://instagram.com/ahmad.younes04"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial px-4 py-3 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-pink-500/50 transition-all duration-300 hover:scale-110 group"
                  title="Instagram"
                >
                  <Instagram size={20} className="text-white" />
                  <span className="hidden sm:inline text-white font-semibold text-sm">Instagram</span>
                </a>
                <a
                  href="mailto:younesahmad58@yahoo.com"
                  className="flex-1 sm:flex-initial px-4 py-3 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-red-500/50 transition-all duration-300 hover:scale-110 group"
                  title="Email"
                >
                  <Mail size={20} className="text-white" />
                  <span className="hidden sm:inline text-white font-semibold text-sm">Email</span>
                </a>
              </div>
            </div>
          </div>

          <div
            className={`transition-all duration-1000 delay-200 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
            }`}
          >
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-3xl opacity-20 blur-xl"></div>

              <form
                onSubmit={handleSubmit}
                className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-3xl p-8 space-y-6"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t.contact.form.fullName}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
                    placeholder={language === 'ro' ? 'Ion Popescu' : 'John Doe'}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t.contact.form.email}
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
                    placeholder={language === 'ro' ? 'ion@exemplu.ro' : 'john@example.com'}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t.contact.form.phone}
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors"
                    placeholder="+40 123 456 789"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t.contact.form.message}
                  </label>
                  <textarea
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={5}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400 transition-colors resize-none"
                    placeholder={language === 'ro' ? 'Descrie-mi proiectul tău...' : 'Tell me about your project...'}
                  />
                </div>

                {showSuccess && (
                  <div className="flex items-center gap-2 px-4 py-3 bg-green-500/20 border border-green-500/50 rounded-xl text-green-400">
                    <CheckCircle size={20} />
                    <span>{t.contact.form.success}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full group flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl text-white font-semibold text-lg hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? t.contact.form.sending : t.contact.form.submit}
                  <Send className="group-hover:translate-x-1 transition-transform" size={20} />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
