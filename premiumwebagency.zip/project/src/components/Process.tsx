import { useEffect, useRef, useState } from 'react';
import { MessageSquare, Palette, Code2, Rocket } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { translations } from '../lib/translations';

const Process = () => {
  const { language } = useLanguage();
  const t = translations[language];

  const steps = t.process.steps.map((step: any, index: number) => {
    const iconMap = [MessageSquare, Palette, Code2, Rocket];
    return {
      icon: iconMap[index],
      title: step.title,
      description: step.description,
      gradient: ['from-cyan-500 to-blue-600', 'from-blue-500 to-purple-600', 'from-purple-500 to-pink-600', 'from-pink-500 to-red-600'][index],
    };
  });

  const [isVisible, setIsVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % steps.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [isVisible]);

  return (
    <section
      id="proces"
      ref={sectionRef}
      className="py-24 bg-gradient-to-b from-gray-900 to-black relative overflow-hidden"
    >
      <div className="absolute inset-0">
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/3 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              {t.process.title}
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {t.process.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className={`relative transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              } ${activeStep === index ? 'scale-105' : 'scale-100'}`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className={`absolute -inset-1 bg-gradient-to-r ${step.gradient} rounded-3xl opacity-0 ${activeStep === index ? 'opacity-100' : ''} transition duration-500 blur`}></div>

              <div className={`relative bg-gray-900/90 backdrop-blur-xl border ${activeStep === index ? 'border-white/30' : 'border-white/10'} rounded-3xl p-8 h-full transition-all duration-500`}>
                <div className="flex items-center justify-between mb-6">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br ${step.gradient} rounded-2xl flex items-center justify-center transform transition-all duration-500 ${activeStep === index ? 'rotate-12 scale-110' : ''}`}
                  >
                    <step.icon size={32} className="text-white" />
                  </div>
                  <div className={`text-6xl font-bold ${activeStep === index ? 'text-white' : 'text-gray-700'} transition-colors`}>
                    0{index + 1}
                  </div>
                </div>

                <h3 className={`text-2xl font-bold mb-3 transition-all ${activeStep === index ? 'text-transparent bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text' : 'text-white'}`}>
                  {step.title}
                </h3>

                <p className="text-gray-400 leading-relaxed">
                  {step.description}
                </p>

                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <div className={`w-8 h-0.5 bg-gradient-to-r ${step.gradient} ${activeStep === index ? 'opacity-100' : 'opacity-30'} transition-opacity`}></div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center gap-2 mt-12">
          {steps.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveStep(index)}
              className={`h-2 rounded-full transition-all duration-300 ${
                activeStep === index ? 'w-12 bg-gradient-to-r from-cyan-400 to-purple-600' : 'w-2 bg-gray-700'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;
