import { useState, useEffect } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Projects from './components/Projects';
import Process from './components/Process';
import Skills from './components/Skills';
import Testimonials from './components/Testimonials';
import CTA, { CTAModal } from './components/CTA';
import Contact from './components/Contact';
import Footer from './components/Footer';
import LanguageSelector from './components/LanguageSelector';

function AppContent() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);

  useEffect(() => {
    const hasSelectedLanguage = localStorage.getItem('language');
    if (!hasSelectedLanguage) {
      setShowLanguageSelector(true);
    }
  }, []);

  return (
    <div className="min-h-screen bg-black overflow-x-hidden">
      {showLanguageSelector && (
        <div onClick={() => setShowLanguageSelector(false)}>
          <LanguageSelector showFullScreen={true} />
        </div>
      )}
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Projects />
      <Process />
      <Skills />
      <Testimonials />
      <CTA onOpenModal={() => setIsModalOpen(true)} />
      <Contact />
      <Footer />
      <CTAModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

export default App;
