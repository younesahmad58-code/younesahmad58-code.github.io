export const translations = {
  ro: {
    nav: {
      home: 'Acasă',
      about: 'Despre',
      services: 'Servicii',
      projects: 'Proiecte',
      process: 'Proces',
      skills: 'Skills',
      testimonials: 'Testimoniale',
      contact: 'Contact',
      cta: 'Cere Ofertă',
    },
    hero: {
      title1: 'Construiesc website-uri',
      title2: 'care vând',
      subtitle: 'Aplicații web moderne, rapide și optimizate pentru conversie. Transformă viziunea ta digitală în realitate.',
      cta1: 'Începe Proiectul Tău',
      cta2: 'Vezi Proiectele',
      stats: [
        { value: '50+', label: 'Proiecte' },
        { value: '100%', label: 'Satisfacție' },
        { value: '24/7', label: 'Support' },
        { value: '5★', label: 'Rating' },
      ],
    },
    about: {
      title: 'Despre Mine',
      text1: 'Sunt un dezvoltator web cu experiență în crearea de soluții digitale performante și moderne. Specializarea mea acoperă întregul spectru al dezvoltării web - de la design până la implementare tehnică avansată.',
      text2: 'Fiecare proiect pe care îl dezvolt este construit cu atenție la detalii, optimizat pentru performanță și gândit pentru a aduce rezultate reale afacerii tale.',
      skills: [
        { label: 'Clean Code', color: 'from-cyan-400 to-blue-500' },
        { label: 'Modern Design', color: 'from-blue-500 to-purple-500' },
        { label: 'Fast & Optimized', color: 'from-purple-500 to-pink-500' },
      ],
    },
    services: {
      title: 'Servicii Premium',
      subtitle: 'Soluții complete pentru prezența ta online',
      items: [
        {
          title: 'Web Design',
          description: 'Design modern, intuitiv și responsive, optimizat pentru experiență utilizator premium.',
        },
        {
          title: 'Development',
          description: 'Aplicații web complexe, scalabile și performante, construite cu tehnologii moderne.',
        },
        {
          title: 'SEO & Optimizare',
          description: 'Optimizare completă pentru motoare de căutare și performanță maximă.',
        },
        {
          title: 'Automatizări',
          description: 'Automatizează procesele de business și optimizează fluxurile de lucru.',
        },
      ],
    },
    projects: {
      title: 'Proiecte Realizate',
      subtitle: 'Experiențe digitale care transformă vizitatori în clienți',
      slide: 'Glisează prin proiecte',
    },
    process: {
      title: 'Procesul Meu de Lucru',
      subtitle: '4 pași simpli către proiectul tău de succes',
      steps: [
        {
          title: 'Consultanță',
          description: 'Analizăm împreună nevoile tale, obiectivele și viziunea pentru proiect.',
        },
        {
          title: 'Design',
          description: 'Creăm un design modern, intuitiv și perfect aliniat cu brandul tău.',
        },
        {
          title: 'Development',
          description: 'Dezvoltăm aplicația cu cele mai noi tehnologii și best practices.',
        },
        {
          title: 'Lansare',
          description: 'Lansăm proiectul și oferim suport continuu pentru creșterea ta.',
        },
      ],
    },
    skills: {
      title: 'Expertiza Tehnică',
      subtitle: 'Skills moderne pentru soluții digitale de excepție',
      items: [
        { name: 'Frontend Development', level: 95 },
        { name: 'Backend Development', level: 90 },
        { name: 'Responsive Design', level: 98 },
        { name: 'Cloud Solutions', level: 85 },
        { name: 'Security & Performance', level: 92 },
        { name: 'Architecture & Scaling', level: 88 },
      ],
    },
    testimonials: {
      title: 'Ce Spun Clienții',
      subtitle: 'Feedback real de la parteneri de încredere',
    },
    cta: {
      title1: 'Gata să transformi',
      title2: 'viziunea în realitate?',
      subtitle: 'Hai să discutăm despre proiectul tău și să creăm împreună ceva extraordinar. Oferă gratis consultanță inițială.',
      button: 'Cere Ofertă Gratuită',
      note: 'Răspuns în maximum 24 ore • Consultație gratuită • Fără obligații',
    },
    contact: {
      title: 'Hai în Contact',
      subtitle: 'Transformă ideea ta într-un proiect de succes',
      heading: 'Începem un proiect împreună?',
      description: 'Sunt aici să te ajut să îți aduci viziunea digitală la viață. Completează formularul și te contactez în cel mai scurt timp pentru o discuție despre nevoile tale.',
      contactDirect: 'Contactează-mă Direct',
      form: {
        fullName: 'Nume complet *',
        email: 'Email *',
        phone: 'Telefon (opțional)',
        message: 'Mesaj *',
        submit: 'Trimite Mesajul',
        sending: 'Se trimite...',
        success: 'Mesaj trimis cu succes! Te contactez în curând.',
      },
    },
    footer: {
      brand: 'WebDev Agency',
      description: 'Transformăm idei în experiențe digitale de excepție. Website-uri și aplicații moderne care aduc rezultate.',
      quickLinks: 'Link-uri Rapide',
      contactInfo: 'Contact',
      socialText: 'Urmărește-mă',
      copyright: 'Made with ❤️ and 💻',
      privacy: 'Politică Confidențialitate',
      terms: 'Termeni și Condiții',
    },
  },
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      projects: 'Projects',
      process: 'Process',
      skills: 'Skills',
      testimonials: 'Testimonials',
      contact: 'Contact',
      cta: 'Get Quote',
    },
    hero: {
      title1: 'I build websites',
      title2: 'that sell',
      subtitle: 'Modern, fast web applications optimized for conversion. Transform your digital vision into reality.',
      cta1: 'Start Your Project',
      cta2: 'View Projects',
      stats: [
        { value: '50+', label: 'Projects' },
        { value: '100%', label: 'Satisfaction' },
        { value: '24/7', label: 'Support' },
        { value: '5★', label: 'Rating' },
      ],
    },
    about: {
      title: 'About Me',
      text1: 'I am a web developer with experience in creating high-performance and modern digital solutions. My expertise covers the entire spectrum of web development - from design to advanced technical implementation.',
      text2: 'Every project I develop is built with meticulous attention to detail, optimized for performance, and designed to deliver real results for your business.',
      skills: [
        { label: 'Clean Code', color: 'from-cyan-400 to-blue-500' },
        { label: 'Modern Design', color: 'from-blue-500 to-purple-500' },
        { label: 'Fast & Optimized', color: 'from-purple-500 to-pink-500' },
      ],
    },
    services: {
      title: 'Premium Services',
      subtitle: 'Complete solutions for your online presence',
      items: [
        {
          title: 'Web Design',
          description: 'Modern, intuitive and responsive design, optimized for premium user experience.',
        },
        {
          title: 'Development',
          description: 'Complex, scalable and performant web applications built with modern technologies.',
        },
        {
          title: 'SEO & Optimization',
          description: 'Complete search engine optimization and maximum performance.',
        },
        {
          title: 'Automations',
          description: 'Automate business processes and optimize workflows.',
        },
      ],
    },
    projects: {
      title: 'Projects Completed',
      subtitle: 'Digital experiences that transform visitors into customers',
      slide: 'Browse through projects',
    },
    process: {
      title: 'My Working Process',
      subtitle: '4 simple steps to your successful project',
      steps: [
        {
          title: 'Consultation',
          description: 'We analyze your needs, goals and vision for the project together.',
        },
        {
          title: 'Design',
          description: 'We create a modern, intuitive design perfectly aligned with your brand.',
        },
        {
          title: 'Development',
          description: 'We develop the application with the latest technologies and best practices.',
        },
        {
          title: 'Launch',
          description: 'We launch the project and provide continuous support for your growth.',
        },
      ],
    },
    skills: {
      title: 'Technical Expertise',
      subtitle: 'Modern skills for exceptional digital solutions',
      items: [
        { name: 'Frontend Development', level: 95 },
        { name: 'Backend Development', level: 90 },
        { name: 'Responsive Design', level: 98 },
        { name: 'Cloud Solutions', level: 85 },
        { name: 'Security & Performance', level: 92 },
        { name: 'Architecture & Scaling', level: 88 },
      ],
    },
    testimonials: {
      title: 'What Clients Say',
      subtitle: 'Real feedback from trusted partners',
    },
    cta: {
      title1: 'Ready to transform',
      title2: 'your vision into reality?',
      subtitle: 'Let\'s discuss your project and create something extraordinary together. Free initial consultation.',
      button: 'Get Free Quote',
      note: 'Response within 24 hours • Free consultation • No obligations',
    },
    contact: {
      title: 'Get In Touch',
      subtitle: 'Transform your idea into a successful project',
      heading: 'Let\'s start a project together?',
      description: 'I\'m here to help you bring your digital vision to life. Fill out the form and I\'ll contact you as soon as possible to discuss your needs.',
      contactDirect: 'Contact Me Directly',
      form: {
        fullName: 'Full Name *',
        email: 'Email *',
        phone: 'Phone (optional)',
        message: 'Message *',
        submit: 'Send Message',
        sending: 'Sending...',
        success: 'Message sent successfully! I\'ll contact you soon.',
      },
    },
    footer: {
      brand: 'WebDev Agency',
      description: 'We transform ideas into exceptional digital experiences. Modern websites and applications that deliver results.',
      quickLinks: 'Quick Links',
      contactInfo: 'Contact',
      socialText: 'Follow Me',
      copyright: 'Made with ❤️ and 💻',
      privacy: 'Privacy Policy',
      terms: 'Terms & Conditions',
    },
  },
};
