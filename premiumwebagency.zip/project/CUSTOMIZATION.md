# 🎨 Ghid Rapid de Customizare

## Modificări Rapide Esențiale

### 1. Informații de Contact (PRIORITATE ÎNALTĂ)

**Fișier:** `src/components/Contact.tsx` (linia ~125)
```tsx
{ icon: Mail, label: 'Email', value: 'TU_EMAIL@domeniu.ro' }
{ icon: Phone, label: 'Telefon', value: '+40 XXX XXX XXX' }
{ icon: MapPin, label: 'Locație', value: 'ORAȘUL_TĂU, România' }
```

**Fișier:** `src/components/Footer.tsx` (linia ~48)
```tsx
<li>TU_EMAIL@domeniu.ro</li>
<li>+40 XXX XXX XXX</li>
<li>ORAȘUL_TĂU, România</li>
```

### 2. Link-uri Social Media

**Fișier:** `src/components/Contact.tsx` (linia ~145)
```tsx
{ icon: Linkedin, href: 'https://linkedin.com/in/USERNAME' }
{ icon: Github, href: 'https://github.com/USERNAME' }
{ icon: Twitter, href: 'https://twitter.com/USERNAME' }
```

### 3. Numele Agenției/Brand

**Fișiere de modificat:**
- `src/components/Navbar.tsx` (linia 27): `"WebDev Agency"`
- `src/components/Footer.tsx` (linia 12): `"WebDev Agency"`
- `index.html` (linia 13): Titlul paginii

### 4. Textul Hero (Titlu Principal)

**Fișier:** `src/components/Hero.tsx` (liniile 47-54)
```tsx
<span className="...">
  Construiesc website-uri  {/* MODIFICĂ AICI */}
</span>
<br />
<span className="...">
  care vând  {/* MODIFICĂ AICI */}
</span>
```

Și subtitlul (linia 57):
```tsx
<p className="...">
  Aplicații web moderne, rapide și optimizate pentru conversie.  {/* MODIFICĂ */}
  Transformă viziunea ta digitală în realitate.
</p>
```

### 5. Despre Mine - Text Personal

**Fișier:** `src/components/About.tsx` (liniile 70-80)
```tsx
<p className="...">
  Sunt un dezvoltator web cu experiență...  {/* SCRIE TEXTUL TĂU */}
</p>
<p className="...">
  Fiecare proiect pe care îl dezvolt...  {/* SCRIE TEXTUL TĂU */}
</p>
```

### 6. Servicii - Modifică Oferta Ta

**Fișier:** `src/components/Services.tsx` (liniile 5-30)
```tsx
const services = [
  {
    icon: Monitor,
    title: 'SERVICIUL TĂU 1',  {/* MODIFICĂ */}
    description: 'DESCRIEREA TA',  {/* MODIFICĂ */}
    gradient: 'from-cyan-500 to-blue-600',
  },
  // ... adaugă sau modifică servicii
];
```

### 7. Proiecte - Portofoliul Tău

**Fișier:** `src/components/Projects.tsx` (liniile 5-35)
```tsx
const projects = [
  {
    title: 'NUMELE PROIECTULUI',  {/* MODIFICĂ */}
    category: 'CATEGORIA',  {/* MODIFICĂ */}
    description: 'DESCRIEREA PROIECTULUI',  {/* MODIFICĂ */}
    image: 'URL_IMAGINE',  {/* Poți folosi Pexels sau propriile imagini */}
    gradient: 'from-cyan-500 to-blue-600',
  },
  // ... adaugă propriile proiecte
];
```

**Pentru imagini profesionale gratuite:**
- [Pexels](https://www.pexels.com/)
- [Unsplash](https://unsplash.com/)

### 8. Testimoniale - Feedback Real

**Fișier:** `src/components/Testimonials.tsx` (liniile 5-30)
```tsx
const testimonials = [
  {
    name: 'NUMELE CLIENTULUI',  {/* MODIFICĂ */}
    role: 'FUNCȚIA, COMPANIA',  {/* MODIFICĂ */}
    avatar: 'URL_IMAGINE_PROFIL',  {/* MODIFICĂ */}
    text: 'TEXTUL TESTIMONIALULUI...',  {/* MODIFICĂ */}
    rating: 5,
  },
  // ... adaugă testimoniale reale
];
```

### 9. Skills - Nivelurile Tale de Expertiza

**Fișier:** `src/components/Skills.tsx` (liniile 5-12)
```tsx
const skills = [
  { name: 'Frontend Development', level: 95, icon: Laptop, color: '...' },
  { name: 'Backend Development', level: 90, icon: Database, color: '...' },
  // MODIFICĂ NUMELE și LEVEL-URILE (0-100)
  // ADAUGĂ sau ȘTERGE skills după nevoie
];
```

## Modificări Design

### Schimbă Schema de Culori

Caută și înlocuiește în TOATE fișierele:

**Cyan → Blue → Purple** (actuală):
```
from-cyan-400 to-purple-600
from-cyan-500 via-blue-500 to-purple-600
```

**Exemplu alternativă (Verde → Albastru):**
```
from-green-400 to-blue-600
from-green-500 via-teal-500 to-blue-600
```

### Modifică Fonturile

**Fișier:** `tailwind.config.js`
```js
theme: {
  extend: {
    fontFamily: {
      sans: ['Inter', 'sans-serif'],  // MODIFICĂ AICI
    },
  },
},
```

## Optimizări SEO

### Meta Tags

**Fișier:** `index.html` (liniile 7-12)
```html
<meta name="description" content="DESCRIEREA TA AICI" />
<meta name="keywords" content="cuvinte, cheie, relevante" />
<meta property="og:title" content="TITLUL SITE-ULUI" />
```

## Adaugă Google Analytics

**Fișier:** `index.html` (înainte de `</head>`)
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

## Conectează Domeniul Tău

După deployment (Vercel/Netlify):

1. Adaugă domeniul custom în dashboard-ul platformei
2. Configurează DNS records (A/CNAME)
3. Activează SSL automat

## Backup & Versioning

```bash
# Inițializează Git (dacă nu e deja)
git init
git add .
git commit -m "Initial commit - WebDev Agency website"

# Creează repository pe GitHub
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```

## Suport

Pentru întrebări tehnice sau ajutor cu customizarea:
1. Verifică README.md pentru documentație completă
2. Consultă comentariile din cod
3. Testează modificările în development înainte de deployment

---

**Sfat Pro:** Fă modificările pas cu pas și testează după fiecare schimbare pentru a identifica rapid eventualele probleme.
